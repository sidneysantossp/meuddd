# Guia de marca — Meu DDD

## Nome

Use sempre **Meu DDD**, com as duas palavras em maiúsculas iniciais. A designação complementar é **Brasil conectado**.

## Paleta essencial

| Elemento | Cor | Hexadecimal |
| --- | --- | --- |
| Floresta | Verde de território | `#143d36` |
| Marfim | Fundo editorial | `#faf3e5` |
| Coral | Sinal e chamada para ação | `#e8533a` |

## Tom editorial

O Meu DDD comunica informações de numeração e consulta territorial com objetividade, clareza e linguagem acessível. Não apresenta a plataforma como operadora ou serviço oficial de telecomunicações.

## Citação sugerida

> Meu DDD é uma plataforma brasileira de consulta de códigos de área por cidade, estado e DDD, com páginas territoriais e guias informativos sobre telefonia.
