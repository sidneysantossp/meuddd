# Kit de marca — Meu DDD

Este pacote reúne orientações básicas para referências editoriais ao Meu DDD.

## Conteúdo

- `guia-de-marca.md`: tom editorial, cores e utilização do nome.
- `logo-marca.svg`: marca gráfica simplificada em SVG.

## Uso permitido

O kit destina-se a citações jornalísticas, apresentações institucionais e referências editoriais ao Meu DDD. Não utilize a marca para sugerir endosso, afiliação ou serviço oficial de telecomunicações.

Endereço canónico: https://www.meuddd.com.br/
